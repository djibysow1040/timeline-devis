import { Timeline } from "./components/Timeline";

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Timeline />
    </div>
  );
}
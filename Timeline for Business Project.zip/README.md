
  # Timeline for Business Project

  This is a code bundle for Timeline for Business Project. The original project is available at https://www.figma.com/design/DgJVguILO52XblCvkjMKBN/Timeline-for-Business-Project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  